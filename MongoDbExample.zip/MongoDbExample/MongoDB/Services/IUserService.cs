﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Models;

namespace MongoDB.Services
{
    public interface IUserService
    {
        List<Users> Get();
        Users Get(string Id);
        Users Create(Users users);
        void Update(string Id, Users users);
        void Remove(string Id);
    }
}
