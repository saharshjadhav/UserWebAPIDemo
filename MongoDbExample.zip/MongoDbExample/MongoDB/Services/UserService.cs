﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Models;

namespace MongoDB.Services
{
    public class UserService : IUserService
    {
        private readonly IMongoCollection<Users> _users;
        public UserService(IUserStoreDatabaseSettings settings,IMongoClient mongoClient)
        {
            mongoClient = new MongoClient(settings.ConnectionString);
            var database = mongoClient.GetDatabase(settings.DatabaseName);
            _users = database.GetCollection<Users>(settings.UsersCollectionName);


            //string connectionstring = "mongodb://127.0.0.1:27017";
            //string databasename = "simple_db";
            //string collectionName = "people";
            //var client = new MongoClient(connectionstring);
            //var db = client.GetDatabase(databasename);
            // var collection = db.GetCollection<PersonModel>(collectionName);
            //var results = collection.Find(_ => true);
        }
        public Users Create(Users users)
        {
            _users.InsertOne(users);
            return users;
        }

        public List<Users> Get()
        {
            string connectionstring = "mongodb://127.0.0.1:27017";
            string databasename = "MyDemoDB";
            string collectionName = "Users1";
            var client = new MongoClient(connectionstring);
            var db = client.GetDatabase(databasename);
            var collection = db.GetCollection<Users>(collectionName);
            var User = new Users { Name="Saharsh",UserName="Sa" };
            collection.InsertOne(User);
            var results = collection.Find(_ => true);
            foreach (var result in results.ToList())
            {
                
               // Console.WriteLine(value: $"{result.Id}:{result.FirstName}{result.LastName}");
            }
            return collection.Find(_ => true).ToList<Users>();

            // return _users.Find(Users => true).ToList();
        }

        public Users Get(string Id)
        {
            return _users.Find(Users => Users.Id==Id).FirstOrDefault();
        }

        public void Remove(string Id)
        {
             _users.DeleteOne(Users => Users.Id == Id);
        }

        public void Update(string Id,Users users)
        {
            _users.ReplaceOne(Users => Users.Id == Id,users);
        }
    }
}
