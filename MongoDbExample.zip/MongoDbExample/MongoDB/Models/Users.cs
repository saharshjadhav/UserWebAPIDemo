﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoDB.Models
{
    [BsonIgnoreExtraElements]
    public class Users
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;
        [BsonElement("name")]
        public string Name { get; set; } = string.Empty;
        [BsonElement("username")]
        public string UserName { get; set; } = string.Empty;
        [BsonElement("email")]
        public string Email { get; set; } = string.Empty;
        [BsonElement("address")]
        public string[] Address { get; set; }
        [BsonElement("phone")]
        public string Phone { get; set; } = string.Empty;
        [BsonElement("website")]
        public string Website { get; set; } = string.Empty;
        [BsonElement("company")]
        public string[] Company { get; set; }


    }
}
