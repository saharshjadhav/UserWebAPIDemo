﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Models;
using MongoDB.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MongoDB.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;
        public UserController(IUserService userService)
        {
            this.userService = userService;
        }
        // GET: api/<UserController>
        [HttpGet]
        public ActionResult<List<Users>> Get()
        {
            return userService.Get();
        }

        // GET api/<UserController>/5
        [HttpGet("{id}")]
        public Users Get(string id)
        {
            var user = userService.Get(id);
            if (user == null)
            {
                //return NotFound($"User with Id={id} not found");
            }
            return user;
        }

        // POST api/<UserController>
        [HttpPost]
        public ActionResult<Users> Post([FromBody] Users users)
        {
            userService.Create(users);
            return CreatedAtAction(nameof(Get), new { id = users.Id }, users);
        }

        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public ActionResult Put(string id, [FromBody] Users users)
        {
            var existingUser = userService.Get(id);
            if (existingUser == null)
            {
                return NotFound($"User not found");
            }
            userService.Update(id,users);
            return NoContent();
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(string id)
        {
            var user = userService.Get(id);
            if (user == null)
            {
                return NotFound($"User with Id ={id} found");
            }
            userService.Remove(user.Id);
            return Ok($"User with Id = {id} deleted");
        }
    }
}
